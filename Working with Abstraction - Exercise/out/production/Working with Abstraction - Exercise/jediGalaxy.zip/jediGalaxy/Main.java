package jediGalaxy;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int[] dimensions = parseInt(scanner.nextLine());

        int rows = dimensions[0];
        int cols = dimensions[1];

        int[][] galaxy = new int[rows][cols];

        int value = 0;
        fillGalaxy(rows, cols, galaxy, value);

        String command = scanner.nextLine();


        while (!command.equals("Let the Force be with you")) {
            int[] jedi = parseInt(command);
            int[] evil = parseInt(scanner.nextLine());

            int evilRow = evil[0];
            int evilCol = evil[1];

            moveEvil(galaxy, evilRow, evilCol);

            int jediRow = jedi[0];
            int jediCol = jedi[1];

            long starsCollected = moveJedi(galaxy, jediRow, jediCol);

            command = scanner.nextLine();

            System.out.println(starsCollected);
        }
        
    }

    private static void moveEvil(int[][] galaxy, int evilRow, int evilCol) {
        while (evilRow >= 0 && evilCol >= 0) {
            if (isInGalaxy(galaxy, evilRow, evilCol)) {
                galaxy[evilRow][evilCol] = 0;
            }
            evilRow--;
            evilCol--;
        }
    }

    private static long moveJedi(int[][] galaxy, int jediRow, int jediCol) {
        long starsCollected = 0;

        while (jediRow >= 0 && jediCol < galaxy[1].length) {
            if (isInGalaxy(galaxy, jediRow, jediCol)) {
                starsCollected += galaxy[jediRow][jediCol];
            }

            jediCol++;
            jediRow--;
        }
        return starsCollected;
    }

    private static boolean isInGalaxy(int[][] galaxy, int row, int col) {
        return row >= 0 && col >= 0 && row < galaxy.length && col < galaxy[row].length;
    }

    private static void fillGalaxy(int rows, int cols, int[][] galaxy, int value) {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                galaxy[i][j] = value++;
            }
        }
    }

    private static int[] parseInt(String command) {
        return Arrays.stream(command.split(" ")).mapToInt(Integer::parseInt).toArray();
    }
}
